
import bpy

class tester:
    def __init__(self):
        print('sucess')



def register():
    bpy.utils.register_class(tester)

def unregister():
    bpy.utils.unregister_class(tester)